export const videoPlayerInit = () => {
    console.log('Video Init');
}