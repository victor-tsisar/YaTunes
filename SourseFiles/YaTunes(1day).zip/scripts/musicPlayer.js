export const musicPlayerInit = () => {
    console.log('Music Init');
}